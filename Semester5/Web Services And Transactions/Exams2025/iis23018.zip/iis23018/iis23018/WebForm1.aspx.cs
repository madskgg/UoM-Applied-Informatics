﻿using iis23018;
using System;

namespace iis23018
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void koumpi_Click(object sender, EventArgs e)
        {
            string sentence = original.Text;
            string word1 = TextBox1.Text;
            string word2 = TextBox2.Text;

            var service = new ExamsJan2025();
            string newWord = service.Antikatastasi(sentence, word1, word2);

            result.Text = $"ΝΕΑ ΦΡΑΣΗ: {newWord}";
        }

        eu.dataaccess.footballpool.ws.Info myWS = new eu.dataaccess.footballpool.ws.Info();

        protected void Page_Load(object sender, EventArgs e)
        {
            string[] results = new string[6];
            int[] results2 = new int[6];
            int count = 0;

            eu.dataaccess.footballpool.ws.tTeamPlayerGoalsRankInfo[] temp = myWS.PlayersWithGoalsRanked();

            foreach (eu.dataaccess.footballpool.ws.tTeamPlayerGoalsRankInfo i in temp)
            {
                int max = -1;

                if (i.iGoals > max)
                {
                    max = i.iGoals;
                    results[count] = i.sName;
                    results2[count] = i.iGoals;
                    count++;
                    if (count > 5) break; 
                }
            }

            eu.dataaccess.footballpool.ws.tPlayerName[] allPlayers = myWS.AllPlayerNames(false);

            foreach (eu.dataaccess.footballpool.ws.tPlayerName player in allPlayers)
            {
                for (int k = 0; k < 6; k++)
                {
                    if (results[k] == player.sName)
                    {
                        results[k] = results[k] + " | " + results2[k] + " | " + player.sCountryName;
                    }
                }
            }

            string output = "Παίκτες | Goal | Ομάδα τους<br/>";
            foreach (string i in results)
            {
                output = output + i + "<br/>";
            }

            Literal1.Text = output;
        }
    }
}